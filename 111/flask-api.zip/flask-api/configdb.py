from urllib.parse import quote_plus

username = 'u187324_GN'
password = '3281#Db-77'
encoded_username = quote_plus(username)
encoded_password = quote_plus(password)